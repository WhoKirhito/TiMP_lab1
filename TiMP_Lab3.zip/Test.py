import unittest
import tempfile
import os
from datetime import time
from menu_app import MenuModel, MenuItem


class TestMenuItem(unittest.TestCase):
    def test_valid_creation(self):
        item = MenuItem("Пицца", 350.50, time(0, 30))
        self.assertEqual(item.name, "Пицца")
        self.assertEqual(item.price, 350.50)
    
    def test_empty_name(self):
        with self.assertRaises(ValueError):
            MenuItem("", 350.50, time(0, 30))
    
    def test_negative_price(self):
        with self.assertRaises(ValueError):
            MenuItem("Пицца", -100, time(0, 30))


class TestMenuModel(unittest.TestCase):
    def setUp(self):
        self.model = MenuModel()
    
    def test_add(self):
        self.model.add("Борщ", 250, time(0, 45))
        self.assertEqual(self.model.count, 1)
        self.assertEqual(self.model.items[0].name, "Борщ")
    
    def test_delete(self):
        self.model.add("Суп", 150, time(0, 30))
        deleted = self.model.delete(0)
        self.assertEqual(deleted.name, "Суп")
        self.assertEqual(self.model.count, 0)
    
    def test_parse_valid(self):
        item = self.model.parse_line('Меню "Пицца" 350.50 12:30')
        self.assertIsNotNone(item)
        self.assertEqual(item.name, "Пицца")
    
    def test_parse_invalid(self):
        item = self.model.parse_line("Меню Пицца 350")
        self.assertIsNone(item)
    
    def test_parse_empty(self):
        item = self.model.parse_line("")
        self.assertIsNone(item)
    
    def test_save_load(self):
        self.model.add("Борщ", 250, time(0, 45))
        with tempfile.NamedTemporaryFile(suffix=".txt", delete=False) as f:
            name = f.name
        try:
            self.model.save(name)
            new = MenuModel()
            new.load(name)
            self.assertEqual(new.count, 1)
            self.assertEqual(new.items[0].name, "Борщ")
        finally:
            os.unlink(name)


if __name__ == "__main__":
    unittest.main()
